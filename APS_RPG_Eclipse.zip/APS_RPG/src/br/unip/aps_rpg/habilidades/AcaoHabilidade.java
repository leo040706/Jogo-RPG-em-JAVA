package br.unip.aps_rpg.habilidades;

import br.unip.aps_rpg.model.Personagem;
import br.unip.aps_rpg.inimigos.Inimigo;

/* =========================
   Habilidade (Functional interface + implementação)
   - Demonstra Interface e Polimorfismo de ação
   ========================= */
public interface AcaoHabilidade {
    void executar(Personagem jogador, Inimigo inimigo);
}