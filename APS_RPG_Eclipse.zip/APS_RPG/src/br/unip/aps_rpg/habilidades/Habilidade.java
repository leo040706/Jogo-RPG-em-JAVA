package br.unip.aps_rpg.habilidades;

import br.unip.aps_rpg.model.Personagem;
import br.unip.aps_rpg.inimigos.Inimigo;

public class Habilidade {
    private final String nome;
    private final int custo; // placeholder
    private int cooldown;
    private int cooldownAtual;
    private final AcaoHabilidade acao;

    public Habilidade(String nome, int custo, int cooldown, AcaoHabilidade acao) {
        this.nome = nome;
        this.custo = custo;
        this.cooldown = cooldown;
        this.cooldownAtual = 0;
        this.acao = acao;
    }

    public String getNome() { return nome; }
    public int getCooldown() { return cooldownAtual; }
    public boolean isDisponivel() { return cooldownAtual == 0; }

    public void usar(Personagem jogador, Inimigo inimigo) {
        if (isDisponivel()) {
            acao.executar(jogador, inimigo);
            cooldownAtual = cooldown;
        } else {
            System.out.println("Habilidade em cooldown.");
        }
    }

    public void resetCooldown() { /* cooldown já setado em usar */ }

    public void tickCooldown() {
        if (cooldownAtual > 0) cooldownAtual--;
    }
}