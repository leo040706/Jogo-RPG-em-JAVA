package br.unip.aps_rpg.main;

public class Main {
    public static void main(String[] args) {
        Jogo jogo = new Jogo();
        jogo.iniciar();
    }
}
