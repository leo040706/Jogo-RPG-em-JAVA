package br.unip.aps_rpg.main;

/* =========================
   FinalNarrativa
   ========================= */
class FinalNarrativa {
    public static void mostrarVitoria() {
        System.out.println("\n--- FINAL: Vitória ---");
        System.out.println("Kevinlito restaura Spland: árvores voltam a crescer, o ar clareia.");
        System.out.println("A cidade celebra sua ação. Missão cumprida!");
    }

    public static void mostrarDerrota() {
        System.out.println("\n--- FINAL: Derrota ---");
        System.out.println("Sem proteção, Spland afunda em poluição. Há sempre uma nova chance.");
    }
}