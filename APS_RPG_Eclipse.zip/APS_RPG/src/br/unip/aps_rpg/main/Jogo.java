package br.unip.aps_rpg.main;

import br.unip.aps_rpg.model.Cidade;
import br.unip.aps_rpg.model.Personagem;
import br.unip.aps_rpg.model.Item;
import br.unip.aps_rpg.inimigos.Inimigo;
import br.unip.aps_rpg.inimigos.MonstroPoluicao;
import br.unip.aps_rpg.inimigos.EspiritoDesperdicio;
import br.unip.aps_rpg.inimigos.SenhorDevastacao;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/* =========================
   Classe Jogo
   - Responsável pelo fluxo principal do jogo
   - Encapsulamento: campos privados
   - Tratamento de Exceções: try/catch em entradas e I/O
   ========================= */
class Jogo {
    private Personagem jogador; // Encapsulamento
    private final Cidade cidade; // Classe Final + atributo final
    private final Scanner scanner = new Scanner(System.in);

    // Salva dentro da pasta do projeto, em subpasta "saves"
    private static final Path SAVE_DIR = Paths.get(System.getProperty("user.dir")).resolve("saves");
    private static final Path SAVE_FILE = SAVE_DIR.resolve("savegame.txt");

    // Construtor
    public Jogo() {
        cidade = new Cidade("Spland"); // Classe Final: Cidade, misturei o nome de SP com Land
    }

    // Inicia o jogo
    public void iniciar() {
        System.out.println("Bem-vindo a Spland! (Digite números para escolher opções)");
        // Cria jogador (sobrecarga de construtor demonstrada em Personagem)
        jogador = new Personagem("Kevinlito, o Eco-Ladino", 100, 15);

        // Itens iniciais
        jogador.adicionarItem(new Item("Garrafa Reutilizável", "cura", 20));
        jogador.adicionarItem(new Item("Armadura Mágica", "defesa", 5));
        jogador.adicionarItem(new Item("Vassoura Sustentável", "forca", 3));
        jogador.adicionarItem(new Item("Sementes Mágicas", "buff_forca", 5));
        jogador.adicionarItem(new Item("Comida Orgânica", "cura", 30));

        menuPrincipal();
    }

    // Menu principal com opções extras (salvar/carregar)
    private void menuPrincipal() {
        int opcao = 0;
        do {
            try {
                System.out.println("\n--- Menu Principal ---");
                System.out.println("1 - Explorar a cidade");
                System.out.println("2 - Lutar contra inimigos ambientais");
                System.out.println("3 - Conversar com NPC (diálogo ramificado)");
                System.out.println("4 - Ver inventário");
                System.out.println("5 - Usar/Equipar item");
                System.out.println("6 - Enfrentar o Boss Final");
                System.out.println("7 - Ver status do herói");
                System.out.println("8 - Loja");
                System.out.println("9 - Salvar jogo");
                System.out.println("10 - Carregar jogo");
                System.out.println("11 - Sair");
                System.out.print("Escolha: ");
                String entrada = scanner.nextLine().trim();
                if (entrada.isEmpty()) throw new NumberFormatException();
                opcao = Integer.parseInt(entrada);

                switch (opcao) {
                    case 1 -> explorarCidade();
                    case 2 -> iniciarCombate();
                    case 3 -> conversarNPCRamificado();
                    case 4 -> jogador.mostrarInventario();
                    case 5 -> menuUsarEquipar();
                    case 6 -> enfrentarBoss();
                    case 7 -> jogador.mostrarStatus();
                    case 8 -> loja();
                    case 9 -> salvarJogo();
                    case 10 -> carregarJogo();
                    case 11 -> System.out.println("Saindo do jogo... até a próxima!");
                    default -> System.out.println("Opção inválida!");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida! Digite apenas números.");
            } catch (Exception e) {
                System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
            }
        } while (opcao != 11);
    }

    private void explorarCidade() {
        double r = Math.random();
        if (r < 0.4) {
            System.out.println("Você encontra uma Vassoura Sustentável!");
            jogador.adicionarItem(new Item("Vassoura Sustentável", "forca", 3));
        } else if (r < 0.7) {
            System.out.println("Você encontra uma Garrafa Reutilizável!");
            jogador.adicionarItem(new Item("Garrafa Reutilizável", "cura", 20));
        } else {
            System.out.println("Você encontra uma Armadura Mágica!");
            jogador.adicionarItem(new Item("Armadura Mágica", "defesa", 5));
        }
    }

    private void iniciarCombate() {
        Inimigo inimigo = Math.random() > 0.5 ? new MonstroPoluicao() : new EspiritoDesperdicio();
        System.out.println("Um " + inimigo.getNome() + " apareceu!");

        combateTurnoAJogador(inimigo);
    }

    // Diálogo ramificado com escolhas que afetam recompensas/progresso
    private void conversarNPCRamificado() {
        System.out.println("\nVocê encontra um ativista ambiental que oferece três opções:");
        System.out.println("1 - Ajudar a plantar árvores (ganha vida e XP)");
        System.out.println("2 - Ajudar a recolher lixo (ganha itens)");
        System.out.println("3 - Ignorar");
        System.out.print("Escolha: ");
        try {
            String s = scanner.nextLine().trim();
            if (s.isEmpty()) throw new NumberFormatException();
            int escolha = Integer.parseInt(s);
            switch (escolha) {
                case 1 -> {
                    System.out.println("Você ajudou a plantar árvores. A cidade agradece!");
                    jogador.receberCura(10);
                    jogador.ganharXP(20);
                }
                case 2 -> {
                    System.out.println("Você recolheu lixo e encontrou itens úteis!");
                    jogador.adicionarItem(new Item("Vassoura Sustentável", "forca", 3));
                    jogador.ganharXP(10);
                }
                case 3 -> System.out.println("Você seguiu seu caminho. Talvez outra hora.");
                default -> System.out.println("Opção inválida.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida! Missão cancelada.");
        }
    }

    // Menu usar/equipar por índice (inventário numerado)
    private void menuUsarEquipar() {
        System.out.println("\n--- Usar ou Equipar Item ---");
        System.out.println("1 - Usar item consumível");
        System.out.println("2 - Equipar item");
        System.out.println("3 - Desequipar item");
        System.out.print("Escolha: ");
        try {
            String s = scanner.nextLine().trim();
            if (s.isEmpty()) throw new NumberFormatException();
            int op = Integer.parseInt(s);
            switch (op) {
                case 1 -> {
                    jogador.mostrarInventario();
                    System.out.print("Digite o número do item consumível (ou 0 para cancelar): ");
                    String idxStr = scanner.nextLine().trim();
                    if (idxStr.isEmpty()) throw new NumberFormatException();
                    int idx = Integer.parseInt(idxStr);
                    if (idx == 0) { System.out.println("Operação cancelada."); return; }
                    jogador.usarItemConsumivelPorIndice(idx - 1);
                }
                case 2 -> {
                    jogador.mostrarInventario();
                    System.out.print("Digite o número do item para equipar (ou 0 para cancelar): ");
                    String idxStr = scanner.nextLine().trim();
                    if (idxStr.isEmpty()) throw new NumberFormatException();
                    int idx = Integer.parseInt(idxStr);
                    if (idx == 0) { System.out.println("Operação cancelada."); return; }
                    jogador.equiparItemPorIndice(idx - 1);
                }
                case 3 -> {
                    System.out.print("Desequipar (1) arma ou (2) armadura? ");
                    String tStr = scanner.nextLine().trim();
                    if (tStr.isEmpty()) throw new NumberFormatException();
                    int t = Integer.parseInt(tStr);
                    if (t == 1) jogador.desequiparArma();
                    else jogador.desequiparArmadura();
                }
                default -> System.out.println("Opção inválida!");
            }
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida!");
        }
    }

    private void enfrentarBoss() {
        Inimigo boss = new SenhorDevastacao();
        System.out.println("O Boss Final apareceu: " + boss.getNome() + "!");

        combateTurnoAJogador(boss);

        if (jogador.estaVivo() && !boss.estaVivo()) {
            System.out.println("Você derrotou o Boss Final! Vitória!");
            jogador.ganharXP(100);
            FinalNarrativa.mostrarVitoria();
        } else if (!jogador.estaVivo()) {
            System.out.println("Você foi derrotado pelo Boss. Fim de jogo.");
            FinalNarrativa.mostrarDerrota();
        }
    }

    // Combate por turnos com opção de habilidades
    private void combateTurnoAJogador(Inimigo inimigo) {
        while (inimigo.estaVivo() && jogador.estaVivo()) {
            System.out.println("\n--- Turno do Jogador ---");
            System.out.println("Inimigo: " + inimigo.getNome() + " (Vida: " + inimigo.getVida() + ")");
            System.out.println("1 - Atacar");
            System.out.println("2 - Usar consumível");
            System.out.println("3 - Habilidades");
            System.out.println("4 - Equipar/Desequipar");
            System.out.println("5 - Fugir");
            System.out.print("Escolha: ");
            String s = scanner.nextLine().trim();
            if (s.isEmpty()) { System.out.println("Entrada inválida!"); continue; }
            int op;
            try { op = Integer.parseInt(s); } catch (NumberFormatException e) { System.out.println("Entrada inválida!"); continue; }

            switch (op) {
                case 1 -> {
                    int dano = jogador.getForcaAtual();
                    System.out.println("Você ataca causando " + dano + " de dano!");
                    inimigo.receberDano(dano);
                }
                case 2 -> {
                    jogador.mostrarInventario();
                    System.out.print("Digite o número do consumível: ");
                    try {
                        int idx = Integer.parseInt(scanner.nextLine().trim()) - 1;
                        jogador.usarItemConsumivelPorIndice(idx);
                    } catch (Exception e) { System.out.println("Entrada inválida!"); }
                }
                case 3 -> {
                    jogador.mostrarHabilidades();
                    System.out.print("Escolha habilidade (número) ou 0 para cancelar: ");
                    try {
                        int h = Integer.parseInt(scanner.nextLine().trim());
                        if (h == 0) break;
                        jogador.usarHabilidade(h, inimigo);
                    } catch (Exception e) { System.out.println("Entrada inválida!"); }
                }
                case 4 -> menuUsarEquipar();
                case 5 -> {
                    if (Math.random() < 0.5) {
                        System.out.println("Você fugiu com sucesso!");
                        return;
                    } else {
                        System.out.println("Fuga falhou!");
                    }
                }
                default -> System.out.println("Opção inválida!");
            }

            if (!inimigo.estaVivo()) {
                System.out.println(inimigo.getNome() + " foi derrotado!");
                jogador.ganharXP(20);
                // drop simples
                if (Math.random() < 0.6) {
                    Item drop = new Item("Comida Orgânica", "cura", 30);
                    jogador.adicionarItem(drop);
                }
                return;
            }

            // Turno do inimigo
            System.out.println("\n--- Turno do Inimigo ---");
            inimigo.atacar(jogador);

            if (!jogador.estaVivo()) {
                System.out.println("Você foi derrotado!");
                return;
            }

            jogador.decrementarBuffs();
        }
    }

    // Loja simples: comprar e vender
    private void loja() {
        System.out.println("\n--- Loja de Spland ---");
        List<Item> estoque = new ArrayList<>();
        estoque.add(new Item("Comida Orgânica", "cura", 30)); // preço implícito
        estoque.add(new Item("Vassoura Sustentável", "forca", 3));
        estoque.add(new Item("Armadura Mágica", "defesa", 5));

        System.out.println("1 - Comprar");
        System.out.println("2 - Vender (pegará o último item do inventário como exemplo)");
        System.out.print("Escolha: ");
        try {
            int op = Integer.parseInt(scanner.nextLine().trim());
            if (op == 1) {
                System.out.println("Itens disponíveis:");
                for (int i = 0; i < estoque.size(); i++) {
                    System.out.println((i + 1) + " - " + estoque.get(i).getNome() + " : " + estoque.get(i).getEfeito());
                }
                System.out.print("Digite o número do item para comprar (ou 0 para cancelar): ");
                int idx = Integer.parseInt(scanner.nextLine().trim());
                if (idx == 0) { System.out.println("Compra cancelada."); return; }
                if (idx < 1 || idx > estoque.size()) { System.out.println("Índice inválido."); return; }
                Item comprado = estoque.get(idx - 1);
                jogador.adicionarItem(comprado);
                System.out.println("Compra realizada: " + comprado.getNome());
            } else if (op == 2) {
                if (jogador.getInventario().isEmpty()) { System.out.println("Nada para vender."); return; }
                Item vendido = jogador.getInventario().remove(jogador.getInventario().size() - 1);
                System.out.println("Você vendeu: " + vendido.getNome() + " (recebeu recompensa simbólica)");
                jogador.ganharXP(5);
            } else {
                System.out.println("Opção inválida.");
            }
        } catch (Exception e) {
            System.out.println("Entrada inválida na loja.");
        }
    }

    // Salvar jogo (agora salva em pasta "saves" dentro da pasta do projeto)
    private void salvarJogo() {
        try {
            Files.createDirectories(SAVE_DIR); // cria pasta se não existir
            try (PrintWriter pw = new PrintWriter(Files.newBufferedWriter(SAVE_FILE))) {
                pw.println(jogador.serialize());
            }
            System.out.println("Jogo salvo em " + SAVE_FILE.toString());
        } catch (IOException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        }
    }

    // Carregar jogo (lê de pasta "saves" dentro da pasta do projeto)
    private void carregarJogo() {
        if (!Files.exists(SAVE_FILE)) {
            System.out.println("Arquivo de save não encontrado em " + SAVE_FILE.toString());
            return;
        }
        try (BufferedReader br = Files.newBufferedReader(SAVE_FILE)) {
            String linha = br.readLine();
            if (linha != null && !linha.isEmpty()) {
                Personagem p = Personagem.deserialize(linha);
                if (p != null) {
                    this.jogador = p;
                    System.out.println("Jogo carregado com sucesso de " + SAVE_FILE.toString());
                } else {
                    System.out.println("Arquivo de save inválido.");
                }
            } else {
                System.out.println("Arquivo de save vazio.");
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar: " + e.getMessage());
        }
    }
}