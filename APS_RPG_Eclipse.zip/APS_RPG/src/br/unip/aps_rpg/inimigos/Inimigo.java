package br.unip.aps_rpg.inimigos;

import br.unip.aps_rpg.model.Personagem;

/* =========================
   Inimigo (Classe Abstrata) - demonstra Classe Abstrata e Polimorfismo
   ========================= */
public abstract class Inimigo {
    protected String nome;
    protected int vida;
    protected int defesa;

    public Inimigo(String nome, int vida, int defesa) { // Construtor
        this.nome = nome;
        this.vida = vida;
        this.defesa = defesa;
    }

    // Método abstrato: sobrescrito nas subclasses (Sobrescrita)
    public abstract void atacar(Personagem jogador);

    public void receberDano(int dano) {
        vida = Math.max(0, vida - dano);
        System.out.println(nome + " recebeu " + dano + " de dano. Vida restante: " + vida);
    }

    public boolean estaVivo() { return vida > 0; }
    public String getNome() { return nome; }
    public int getVida() { return vida; }
    public int getDefesa() { return defesa; }
}