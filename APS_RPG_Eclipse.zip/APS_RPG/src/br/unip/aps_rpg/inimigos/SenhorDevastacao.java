package br.unip.aps_rpg.inimigos;

import br.unip.aps_rpg.model.Personagem;

public class SenhorDevastacao extends Inimigo {
    public SenhorDevastacao() { super("Senhor Devastação - Poluição do Ar", 150, 10); }
    @Override
    public void atacar(Personagem jogador) {
        int escolha = (int)(Math.random() * 2);
        if (escolha == 0) {
            int dano = 20;
            System.out.println(nome + " libera uma nuvem tóxica sufocante!");
            jogador.receberDano(dano);
        } else {
            int dano = 25;
            System.out.println(nome + " cobre Spland com fumaça negra!");
            jogador.receberDano(dano);
        }
    }
}