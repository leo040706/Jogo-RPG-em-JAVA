package br.unip.aps_rpg.inimigos;

import br.unip.aps_rpg.model.Personagem;

/* =========================
   Subclasses de Inimigo (Herança, Sobrescrita)
   ========================= */
public class MonstroPoluicao extends Inimigo {
    public MonstroPoluicao() { super("Monstro da Poluição", 80, 5); } // Herança
    @Override
    public void atacar(Personagem jogador) { // Sobrescrita
        int dano = 12;
        System.out.println(nome + " lança fumaça tóxica!");
        jogador.receberDano(dano);
    }
}