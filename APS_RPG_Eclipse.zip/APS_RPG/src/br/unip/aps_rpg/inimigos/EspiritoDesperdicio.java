package br.unip.aps_rpg.inimigos;

import br.unip.aps_rpg.model.Personagem;

public class EspiritoDesperdicio extends Inimigo {
    public EspiritoDesperdicio() { super("Espírito do Desperdício", 60, 3); }
    @Override
    public void atacar(Personagem jogador) {
        int dano = (int)(Math.random() * 15);
        System.out.println(nome + " joga lixo ao redor!");
        jogador.receberDano(dano);
    }
}
