package br.unip.aps_rpg.model;

import br.unip.aps_rpg.habilidades.AcaoHabilidade;
import br.unip.aps_rpg.habilidades.Habilidade;
import br.unip.aps_rpg.inimigos.Inimigo;

import java.util.*;

    /* =========================
   Classe Personagem
   - Encapsulamento, Construtor, Sobrecarga, Polimorfismo (usa Inimigo), Progressão, Habilidades
   ========================= */
public class Personagem {
    private String nome; // Encapsulamento
    private int vida;
    private int vidaMax;
    private int forca;
    private int nivel;
    private int xp;
    private List<Item> inventario = new ArrayList<>();

    // Equipamentos persistentes
    private Item armaEquipada = null;
    private Item armaduraEquipada = null;

    // Buffs temporários
    private List<Buff> buffs = new ArrayList<>();

    // Habilidades (exemplo simples)
    private List<Habilidade> habilidades = new ArrayList<>();

    // Construtor principal
    public Personagem(String nome, int vidaMax, int forca) {
        this.nome = nome;
        this.vidaMax = vidaMax;
        this.vida = vidaMax;
        this.forca = forca;
        this.nivel = 1;
        this.xp = 0;
        // Habilidades iniciais
        habilidades.add(new Habilidade("Golpe Rápido", 0, 1, (j, inimigo) -> {
            int dano = j.getForcaAtual();
            System.out.println(j.getNome() + " usa Golpe Rápido causando " + dano + " de dano!");
            inimigo.receberDano(dano);
        }));
        habilidades.add(new Habilidade("Investida Forte", 0, 2, (j, inimigo) -> {
            int dano = j.getForcaAtual() + 5;
            System.out.println(j.getNome() + " usa Investida Forte causando " + dano + " de dano!");
            inimigo.receberDano(dano);
        }));
    }

    // Sobrecarga de construtor
    public Personagem(String nome) { this(nome, 80, 10); }

    // Getters
    public String getNome() { return nome; }
    public int getVidaAtual() { return vida; }
    public int getVidaMax() { return vidaMax; }
    public List<Item> getInventario() { return inventario; }

    // Adiciona item
    public void adicionarItem(Item item) {
        if (item == null) return;
        inventario.add(item);
        System.out.println("Item adicionado: " + item.getNome());
    }

    // Recupera vida
    public void receberCura(int cura) {
        vida = Math.min(vidaMax, vida + cura);
        System.out.println(nome + " recuperou " + cura + " de vida. Vida atual: " + vida);
    }

    // Recebe dano considerando armadura equipada
    public void receberDano(int dano) {
        int reducao = (armaduraEquipada != null && "defesa".equals(armaduraEquipada.getTipo())) ? armaduraEquipada.getValor() : 0;
        int danoFinal = Math.max(0, dano - reducao);
        vida = Math.max(0, vida - danoFinal);
        System.out.println(nome + " recebeu " + danoFinal + " de dano (redução " + reducao + "). Vida restante: " + vida);
    }

    public boolean estaVivo() { return vida > 0; }

    // Cálculo de força atual (considera arma e buffs)
    public int getForcaAtual() {
        int bonusArma = (armaEquipada != null && "forca".equals(armaEquipada.getTipo())) ? armaEquipada.getValor() : 0;
        int bonusBuff = getBuffValue("forca");
        return forca + bonusArma + bonusBuff + (nivel - 1); // leve progressão por nível
    }

    // Ataque padrão (polimorfismo: usado contra Inimigo)
    public void atacar(Inimigo inimigo) {
        int dano = getForcaAtual();
        System.out.println(nome + " ataca causando " + dano + " de dano!");
        inimigo.receberDano(dano);
    }

    // Mostrar inventário numerado
    public void mostrarInventario() {
        System.out.println("\n--- Inventário ---");
        if (inventario.isEmpty()) {
            System.out.println("Inventário vazio.");
        } else {
            for (int i = 0; i < inventario.size(); i++) {
                Item item = inventario.get(i);
                System.out.println((i + 1) + " - " + item.getNome() + " : " + item.getEfeito());
            }
        }
        System.out.println("Arma equipada: " + (armaEquipada != null ? armaEquipada.getNome() : "Nenhuma"));
        System.out.println("Armadura equipada: " + (armaduraEquipada != null ? armaduraEquipada.getNome() : "Nenhuma"));
    }

    // Usar consumível por índice (robusto)
    public void usarItemConsumivelPorIndice(int indice) {
        if (indice < 0 || indice >= inventario.size()) {
            System.out.println("Índice inválido!");
            return;
        }
        Item item = inventario.get(indice);
        if (item == null) { System.out.println("Item inválido."); return; }
        String tipo = item.getTipo().toLowerCase();
        switch (tipo) {
            case "cura":
                receberCura(item.getValor());
                inventario.remove(indice);
                System.out.println(item.getNome() + " usado com sucesso!");
                return;
            case "buff_forca":
                buffs.add(new Buff("forca", item.getValor(), 3));
                inventario.remove(indice);
                System.out.println(item.getNome() + " usado: + " + item.getValor() + " de força por 3 turnos!");
                return;
            default:
                System.out.println("Item não é consumível. Tente equipar.");
                return;
        }
    }

    // Equipar por índice (robusto)
    public void equiparItemPorIndice(int indice) {
        if (indice < 0 || indice >= inventario.size()) {
            System.out.println("Índice inválido!");
            return;
        }
        Item item = inventario.get(indice);
        if (item == null) { System.out.println("Item inválido."); return; }
        String tipo = item.getTipo().toLowerCase();
        if ("forca".equals(tipo)) {
            armaEquipada = item;
            inventario.remove(indice);
            System.out.println("Você equipou a arma: " + item.getNome());
        } else if ("defesa".equals(tipo)) {
            armaduraEquipada = item;
            inventario.remove(indice);
            System.out.println("Você equipou a armadura: " + item.getNome());
        } else {
            System.out.println("Este item não pode ser equipado.");
        }
    }

    // Métodos por nome (compatibilidade)
    public void usarItemConsumivel(String nomeItem) {
        if (nomeItem == null) { System.out.println("Nome inválido."); return; }
        String nomeNormalizado = nomeItem.trim();
        Iterator<Item> it = inventario.iterator();
        while (it.hasNext()) {
            Item item = it.next();
            if (item.getNome().equalsIgnoreCase(nomeNormalizado)) {
                switch (item.getTipo()) {
                    case "cura":
                        receberCura(item.getValor());
                        it.remove();
                        return;
                    case "buff_forca":
                        buffs.add(new Buff("forca", item.getValor(), 3));
                        System.out.println("Você ganhou + " + item.getValor() + " de força por 3 turnos!");
                        it.remove();
                        return;
                    default:
                        System.out.println("Item não é consumível. Tente equipar.");
                        return;
                }
            }
        }
        System.out.println("Item não encontrado!");
    }

    public void equiparItem(String nomeItem) {
        if (nomeItem == null) { System.out.println("Nome inválido."); return; }
        String nomeNormalizado = nomeItem.trim();
        Iterator<Item> it = inventario.iterator();
        while (it.hasNext()) {
            Item item = it.next();
            if (item.getNome().equalsIgnoreCase(nomeNormalizado)) {
                if ("forca".equals(item.getTipo())) {
                    armaEquipada = item;
                    it.remove();
                    System.out.println("Você equipou a arma: " + item.getNome());
                    return;
                } else if ("defesa".equals(item.getTipo())) {
                    armaduraEquipada = item;
                    it.remove();
                    System.out.println("Você equipou a armadura: " + item.getNome());
                    return;
                } else {
                    System.out.println("Este item não pode ser equipado.");
                    return;
                }
            }
        }
        System.out.println("Item não encontrado no inventário!");
    }

    public void desequiparArma() {
        if (armaEquipada != null) {
            adicionarItem(armaEquipada);
            System.out.println("Desequipou: " + armaEquipada.getNome());
            armaEquipada = null;
        } else {
            System.out.println("Nenhuma arma equipada.");
        }
    }

    public void desequiparArmadura() {
        if (armaduraEquipada != null) {
            adicionarItem(armaduraEquipada);
            System.out.println("Desequipou: " + armaduraEquipada.getNome());
            armaduraEquipada = null;
        } else {
            System.out.println("Nenhuma armadura equipada.");
        }
    }

    // Buffs
    private int getBuffValue(String tipo) {
        int soma = 0;
        for (Buff b : buffs) {
            if (b.getTipo().equals(tipo)) soma += b.getValor();
        }
        return soma;
    }

    public void decrementarBuffs() {
        Iterator<Buff> it = buffs.iterator();
        while (it.hasNext()) {
            Buff b = it.next();
            b.decrementarTurno();
            if (b.getTurnosRestantes() <= 0) {
                System.out.println("O efeito de " + b.getTipo() + " de +" + b.getValor() + " expirou.");
                it.remove();
            }
        }
    }

    // Habilidades
    public void mostrarHabilidades() {
        System.out.println("\n--- Habilidades ---");
        for (int i = 0; i < habilidades.size(); i++) {
            Habilidade h = habilidades.get(i);
            System.out.println((i + 1) + " - " + h.getNome() + " (Cooldown: " + h.getCooldown() + ")");
        }
    }

    public void usarHabilidade(int indice, Inimigo inimigo) {
        if (indice < 1 || indice > habilidades.size()) {
            System.out.println("Habilidade inválida.");
            return;
        }
        Habilidade h = habilidades.get(indice - 1);
        if (h.isDisponivel()) {
            h.usar(this, inimigo);
            h.resetCooldown();
        } else {
            System.out.println("Habilidade em cooldown. Aguarde " + h.getCooldown() + " turnos.");
        }
    }

    // Progressão: XP e nível simples (coloquei tipo jogo de RPG mesmo que os personagens ganham nivel)
    public void ganharXP(int quantidade) {
        xp += quantidade;
        System.out.println("Você ganhou " + quantidade + " XP.");
        while (xp >= nivel * 50) {
            xp -= nivel * 50;
            nivel++;
            vidaMax += 10;
            vida = vidaMax;
            forca += 2;
            System.out.println("Parabéns! Você subiu para o nível " + nivel + "!");
        }
    }

    public void mostrarStatus() {
        System.out.println("\n--- Status de " + nome + " ---");
        System.out.println("Vida: " + vida + " / " + vidaMax);
        System.out.println("Força base: " + forca);
        System.out.println("Nível: " + nivel + " | XP: " + xp + "/" + (nivel * 50));
        System.out.println("Bônus de arma: " + (armaEquipada != null ? armaEquipada.getValor() : 0));
        System.out.println("Bônus de buffs (força): " + getBuffValue("forca"));
        System.out.println("Armadura (redução): " + (armaduraEquipada != null ? armaduraEquipada.getValor() : 0));
    }

    // Serialização simples para salvar (classe por classe não exigida aqui)
    public String serialize() {
        StringBuilder sb = new StringBuilder();
        sb.append(nome).append("|").append(vida).append("|").append(vidaMax).append("|").append(forca)
          .append("|").append(nivel).append("|").append(xp).append("|");
        // inventario: nome;tipo;valor, separated by #
        for (int i = 0; i < inventario.size(); i++) {
            Item it = inventario.get(i);
            sb.append(it.getNome().replace("|","/")).append(";").append(it.getTipo()).append(";").append(it.getValor());
            if (i < inventario.size() - 1) sb.append("#");
        }
        // arma/armadura equipadas (nome only)
        sb.append("|").append(armaEquipada != null ? armaEquipada.getNome().replace("|","/") : "");
        sb.append("|").append(armaduraEquipada != null ? armaduraEquipada.getNome().replace("|","/") : "");
        return sb.toString();
    }

    // Desserialização simples
    public static Personagem deserialize(String linha) {
        try {
            String[] parts = linha.split("\\|", -1);
            if (parts.length < 9) return null;
            Personagem p = new Personagem(parts[0], Integer.parseInt(parts[2]), Integer.parseInt(parts[3]));
            p.vida = Integer.parseInt(parts[1]);
            p.nivel = Integer.parseInt(parts[4]);
            p.xp = Integer.parseInt(parts[5]);
            String inv = parts[6];
            if (!inv.isEmpty()) {
                String[] itens = inv.split("#");
                for (String it : itens) {
                    String[] campos = it.split(";");
                    if (campos.length >= 3) {
                        p.adicionarItem(new Item(campos[0], campos[1], Integer.parseInt(campos[2])));
                    }
                }
            }
            String armaNome = parts[7];
            String armaduraNome = parts[8];
            // equipar por nome se existir no inventario
            if (!armaNome.isEmpty()) {
                for (Iterator<Item> it = p.inventario.iterator(); it.hasNext();) {
                    Item item = it.next();
                    if (item.getNome().equalsIgnoreCase(armaNome)) {
                        p.armaEquipada = item;
                        it.remove();
                        break;
                    }
                }
            }
            if (!armaduraNome.isEmpty()) {
                for (Iterator<Item> it = p.inventario.iterator(); it.hasNext();) {
                    Item item = it.next();
                    if (item.getNome().equalsIgnoreCase(armaduraNome)) {
                        p.armaduraEquipada = item;
                        it.remove();
                        break;
                    }
                }
            }
            return p;
        } catch (Exception e) {
            return null;
        }
    }
}