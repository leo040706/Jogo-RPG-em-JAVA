package br.unip.aps_rpg.model;

/* =========================
   Interface Equipavel e Classe Item
   - Interface: demonstra contrato; Item implementa Equipavel
   - Atributo Estático: totalItemsCriados
   - Sobrecarga de Construtor
   ========================= */
public interface Equipavel {
    String getNome();
    String getTipo();
    int getValor();
}