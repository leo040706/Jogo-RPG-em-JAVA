package br.unip.aps_rpg.model;

/* =========================
   Buff
   ========================= */
public class Buff {
    private final String tipo;
    private final int valor;
    private int turnosRestantes;

    public Buff(String tipo, int valor, int turnos) {
        this.tipo = tipo;
        this.valor = valor;
        this.turnosRestantes = turnos;
    }

    public String getTipo() { return tipo; }
    public int getValor() { return valor; }
    public int getTurnosRestantes() { return turnosRestantes; }
    public void decrementarTurno() { turnosRestantes--; }
}