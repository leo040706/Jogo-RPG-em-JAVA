package br.unip.aps_rpg.model;

public class Item implements Equipavel {
    private final String nome; // Encapsulamento
    private final String tipo; // cura, forca, defesa, buff_forca
    private final int valor;
    private static int totalItemsCriados = 0; // Atributo Estático

    public Item(String nome, String tipo, int valor) {
        this.nome = nome;
        this.tipo = tipo;
        this.valor = valor;
        totalItemsCriados++;
    }

    public Item(String nome, String tipo) { this(nome, tipo, 1); } // Sobrecarga

    public String getNome() { return nome; }
    public String getTipo() { return tipo; }
    public int getValor() { return valor; }
    public static int getTotalItemsCriados() { return totalItemsCriados; }

    public String getEfeito() {
        switch (tipo) {
            case "cura": return "Recupera " + valor + " de vida";
            case "forca": return "Aumenta ataque em +" + valor + " (equipável)";
            case "defesa": return "Reduz dano recebido em -" + valor + " (equipável)";
            case "buff_forca": return "Buff temporário: +" + valor + " de força por 3 turnos";
            default: return "Efeito desconhecido";
        }
    }
}