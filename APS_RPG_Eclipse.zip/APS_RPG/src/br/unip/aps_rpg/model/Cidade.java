package br.unip.aps_rpg.model;

/* =========================
   Classe Cidade
   - Classe Final (não pode ser estendida)
   - Encapsulamento: atributo privado final
   ========================= */
public final class Cidade {
    private final String nome; // atributo final

    public Cidade(String nome) { this.nome = nome; } // Construtor

    public String getNome() { return nome; } // getter
}
